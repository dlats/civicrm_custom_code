<?php

/**
 * AclRole.Create API specification (optional)
 * This is used for documentation and validation.
 *
 * @param array $spec description of fields supported by this API call
 * @return void
 * @see http://wiki.civicrm.org/confluence/display/CRM/API+Architecture+Standards
 */
function _civicrm_api3_acl_entity_role_create_spec(&$spec) {
 // $spec['magicword']['api.required'] = 1;
}

/**
 * AclRole.Create API
 *
 * @param array $params
 * @return array API result descriptor
 * @see civicrm_api3_create_success
 * @see civicrm_api3_create_error
 * @throws API_Exception
 */
function civicrm_api3_acl_entity_role_create($params) {
  if (array_key_exists('entity_id', $params) && array_key_exists('acl_role_id', $params)  ) {


      $params['entity_table'] = 'civicrm_group';
      $params['is_active'] = '1';
      CRM_ACL_BAO_EntityRole::create($params);
      //$dao = &CRM_Core_DAO::executeQuery("Insert into civicrm_acl_entity_role (acl_role_id, entity_table, entity_id, is_active) values(".$params['acl_role_id'].",'civicrm_group', ".$params['entity_id'].", '1' )");
    
    $returnValues = '';
    
    return civicrm_api3_create_success($returnValues, $params, 'AclRole', 'Create');
  } else {
    throw new API_Exception(/*errorMessage*/ 'No entity_id or entity_table', /*errorCode*/ 1234);
  }
}

