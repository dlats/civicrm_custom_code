<?php

/**
 * AclEntityRole.Delete API specification (optional)
 * This is used for documentation and validation.
 *
 * @param array $spec description of fields supported by this API call
 * @return void
 * @see http://wiki.civicrm.org/confluence/display/CRM/API+Architecture+Standards
 */
function _civicrm_api3_acl_entity_role_delete_spec(&$spec) {
  //$spec['id']['api.required'] = 1;
}

/**
 * AclEntityRole.Delete API
 *
 * @param array $params
 * @return array API result descriptor
 * @see civicrm_api3_create_success
 * @see civicrm_api3_create_error
 * @throws API_Exception
 */
function civicrm_api3_acl_entity_role_delete($params) {
  if (array_key_exists('id', $params)){
    
    $dao = &CRM_Core_DAO::executeQuery("delete from civicrm_acl_entity_role where id =".$params['id']);
    $returnValues = 'Deleted id = '.$params['id'];
    // ALTERNATIVE: $returnValues = array(); // OK, success
    // ALTERNATIVE: $returnValues = array("Some value"); // OK, return a single value

    // Spec: civicrm_api3_create_success($values = 1, $params = array(), $entity = NULL, $action = NULL)
    return civicrm_api3_create_success($returnValues, $params, 'NewEntity', 'NewAction');
  
  }else{
     throw new API_Exception(/*errorMessage*/ 'id is required.', /*errorCode*/ 1234);
  }
}

