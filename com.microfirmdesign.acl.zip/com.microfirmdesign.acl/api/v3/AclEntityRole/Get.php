<?php

/**
 * AclEntityRole.Get API specification (optional)
 * This is used for documentation and validation.
 *
 * @param array $spec description of fields supported by this API call
 * @return void
 * @see http://wiki.civicrm.org/confluence/display/CRM/API+Architecture+Standards
 */
function _civicrm_api3_acl_entity_role_get_spec(&$spec) {
  //$spec['magicword']['api.required'] = 1;
}

/**
 * AclEntityRole.Get API
 *
 * @param array $params
 * @return array API result descriptor
 * @see civicrm_api3_create_success
 * @see civicrm_api3_create_error
 * @throws API_Exception
 */
function civicrm_api3_acl_entity_role_get($params) {

      $returnValues = array();
      $where = "acl_role_id != 'X3f45ghj' and ";
    
      foreach($params as $fn=>$val){
          if($fn == 'id' or $fn == 'acl_role_id' or $fn == 'entity_table' or $fn == 'entity_id'){
          $where .= $fn." = '".$val."' and ";
        }
      }
      $where = substr($where,0,-4);
      
      $dao = &CRM_Core_DAO::executeQuery("select * from civicrm_acl_entity_role where ".$where);
      while ($dao->fetch()) {
        $returnValues[] = array($dao->id=>array('id'=>$dao->id,'acl_role_id'=>$dao->acl_role_id,'entity_table'=>$dao->entity_table,'entity_id'=>$dao->entity_id,'is_active'=>$dao->is_active));
      }
    
    // Spec: civicrm_api3_create_success($values = 1, $params = array(), $entity = NULL, $action = NULL)
    return civicrm_api3_create_success($returnValues, $params, 'AclEntityRole', 'Get');
  
}

