<?php

/**
 * AclRole.Delete API specification (optional)
 * This is used for documentation and validation.
 *
 * @param array $spec description of fields supported by this API call
 * @return void
 * @see http://wiki.civicrm.org/confluence/display/CRM/API+Architecture+Standards
 */
function _civicrm_api3_acl_role_delete_spec(&$spec) {
  $spec['id']['api.required'] = 1;
}

/**
 * AclRole.Delete API
 *
 * @param array $params
 * @return array API result descriptor
 * @see civicrm_api3_create_success
 * @see civicrm_api3_create_error
 * @throws API_Exception
 */
function civicrm_api3_acl_role_delete($params) {
  if (array_key_exists('id', $params)) {
    $params['version'] = '3';
    $results=civicrm_api("OptionValue","delete", $params);
    if($results['is_error'] == 1){
      $returnValues = $results['error_message'];
    }else{
      $returnValues = 'Deleted id = '.$params['id'];
    }
    //dpm($results);
    // ALTERNATIVE: $returnValues = array(); // OK, success
    // ALTERNATIVE: $returnValues = array("Some value"); // OK, return a single value

    // Spec: civicrm_api3_create_success($values = 1, $params = array(), $entity = NULL, $action = NULL)
    return civicrm_api3_create_success($returnValues, $params, 'AclRole', 'Delete');
  } else {
    throw new API_Exception(/*errorMessage*/ 'Id is required.', /*errorCode*/ 1234);
  }
}

