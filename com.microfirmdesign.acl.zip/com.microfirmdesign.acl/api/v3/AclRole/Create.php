<?php

/**
 * AclRole.Create API specification (optional)
 * This is used for documentation and validation.
 *
 * @param array $spec description of fields supported by this API call
 * @return void
 * @see http://wiki.civicrm.org/confluence/display/CRM/API+Architecture+Standards
 */
function _civicrm_api3_acl_role_create_spec(&$spec) {
  $spec['name']['api.required'] = 1;
}

/**
 * AclRole.Create API
 *
 * @param array $params
 * @return array API result descriptor
 * @see civicrm_api3_create_success
 * @see civicrm_api3_create_error
 * @throws API_Exception
 */
function civicrm_api3_acl_role_create($params) {
  if (array_key_exists('name', $params) ) {
    //
      $params['version']= '3';
       
        $params['option_group_id'] ='8';
        
        $params['is_active'] = '1';
        
    //dpm($params);  
      $results=civicrm_api("OptionValue","create", $params);
    
    $returnValues = '';
    
    return civicrm_api3_create_success($returnValues, $params, 'AclRole', 'Create');
  } else {
    throw new API_Exception(/*errorMessage*/ 'No name', /*errorCode*/ 1234);
  }
}

