<?php

/**
 * AclRole.Get API specification (optional)
 * This is used for documentation and validation.
 *
 * @param array $spec description of fields supported by this API call
 * @return void
 * @see http://wiki.civicrm.org/confluence/display/CRM/API+Architecture+Standards
 */
function _civicrm_api3_acl_role_get_spec(&$spec) {
  //$spec['magicword']['api.required'] = 1;
}

/**
 * AclRole.Get API
 *
 * @param array $params
 * @return array API result descriptor
 * @see civicrm_api3_create_success
 * @see civicrm_api3_create_error
 * @throws API_Exception
 */
function civicrm_api3_acl_role_get($params) {
  
    
    $par['version']= '3';
    $par['name'] = 'acl_role';
    $results=civicrm_api("OptionGroup","get", $par);
    
    $params['option_group_id'] = $results['id']; 
   // $params['is_active'] = '1';
        
    //dpm($params);
    $returnValues =array();
    $results=civicrm_api("OptionValue","get", $params);
    foreach($results['values'] as $x){
      $returnValues[] = $x;
    }
  
    
    //$returnValues = array("Some value"); // OK, return a single value

    // Spec: civicrm_api3_create_success($values = 1, $params = array(), $entity = NULL, $action = NULL)
    return civicrm_api3_create_success($returnValues, $params, 'AclRole', 'Get');
  
}

