<?php

/**
 * AclAcl.Create API specification (optional)
 * This is used for documentation and validation.
 *
 * @param array $spec description of fields supported by this API call
 * @return void
 * @see http://wiki.civicrm.org/confluence/display/CRM/API+Architecture+Standards
 */
function _civicrm_api3_acl_acl_create_spec(&$spec) {
 // $spec['magicword']['api.required'] = 1;
}

/**
 * AclRole.Create API
 *
 * @param array $params
 * @return array API result descriptor
 * @see civicrm_api3_create_success
 * @see civicrm_api3_create_error
 * @throws API_Exception
 */
function civicrm_api3_acl_acl_create($params) {
  if (array_key_exists('entity_id', $params)
    && array_key_exists('name', $params)     
    && array_key_exists('operation', $params)
    && array_key_exists('object_table', $params)
    && array_key_exists('object_id', $params)) {

    $params['is_active'] = '1';
    $params['deny'] = 0;
    $params['entity_table'] = 'civicrm_acl_role';

    CRM_ACL_BAO_ACL::create($params);  
    $returnValues = '';
    return civicrm_api3_create_success($returnValues, $params, 'AclAcl', 'Create');
  } else {
    throw new API_Exception(/*errorMessage*/ 'Need entity_id, name, operation, object_table and object_id', /*errorCode*/ 1234);
  }
}

