<?php

/**
 * AclAcl.Get API specification (optional)
 * This is used for documentation and validation.
 *
 * @param array $spec description of fields supported by this API call
 * @return void
 * @see http://wiki.civicrm.org/confluence/display/CRM/API+Architecture+Standards
 */
function _civicrm_api3_acl_acl_get_spec(&$spec) {
  //$spec['magicword']['api.required'] = 1;
}

/**
 * AclAcl.Get API
 *
 * @param array $params
 * @return array API result descriptor
 * @see civicrm_api3_create_success
 * @see civicrm_api3_create_error
 * @throws API_Exception
 */
function civicrm_api3_acl_acl_get($params) {
    $returnValues = array();
    $where = "name != 'X3f45ghj' and ";
    
    foreach($params as $fn=>$val){
      if($fn == 'id' or $fn == 'name' or $fn == 'entity_table' or $fn == 'entity_id' or $fn == 'operation' or $fn == 'object_table' or $fn == 'object_id'){
        $where .= $fn." = '".$val."' and ";
      }
    }
    $where = substr($where,0,-4);
    //dpm('where = '.$where);
    $sql = "select * from civicrm_acl where ".$where;
    $dao = &CRM_Core_DAO::executeQuery($sql);
      while ($dao->fetch()) {
        $returnValues[] = array($dao->id=>array('id'=>$dao->id,'name'=>$dao->name,'deny'=>$dao->deny,
              'entity_table'=>$dao->entity_table,'entity_id'=>$dao->entity_id,'operation'=>$dao->operation,
              'object_table'=>$dao->object_table,'object_id'=>$dao->object_id, 'is_active'=>$dao->is_active));
      }
    
    // ALTERNATIVE: $returnValues = array(); // OK, success
    // ALTERNATIVE: $returnValues = array("Some value"); // OK, return a single value

    // Spec: civicrm_api3_create_success($values = 1, $params = array(), $entity = NULL, $action = NULL)
    return civicrm_api3_create_success($returnValues, $params, 'AclAcl', 'Get');
 // } else {
   // throw new API_Exception(/*errorMessage*/ 'Everyone knows that the magicword is "sesame"', /*errorCode*/ 1234);
  //}
}

